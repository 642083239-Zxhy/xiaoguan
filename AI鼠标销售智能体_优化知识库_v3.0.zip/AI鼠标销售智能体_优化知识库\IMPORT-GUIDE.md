---
module: import-guide
title: 阿里云百炼导入指南
visibility: internal
publication_status: published
updated: 2026-08-05
---

# 阿里云百炼导入指南

## 第一步：先确认商品事实

检查以下文件中的价格、参数、兼容性、质保和配件。确认后把 `publication_status: draft` 改为 `published`：

- 01-product-catalog.md
- 04-product-comparison.md
- 06-product-faq.md
- 07-accessories-and-package.md
- 08-warranty-and-support.md

## 第二步：创建客户事实知识库

只上传上面已经改为 `published` 的客户事实文件。建议按二级标题切分，表格整块保留，召回结果返回文件名、`source_id` 和更新时间。

## 第三步：配置系统规则

以下文件更适合放在应用提示词、工作流或独立受限知识库中，不要与商品事实混合：

- 00-scope-and-answer-policy.md
- 02-user-needs-and-discovery.md
- 03-recommendation-rules.md
- 05-pricing-and-quote-rules.md
- 09-session-memory-and-customer-data.md
- 10-exception-and-refusal.md

## 第四步：排除内部目录

`internal/`、`OPTIMIZATION-REPORT.md` 和本导入指南不得加入客户端问答索引。

## 第五步：验证

至少测试以下问题：预算不足、兼容性未知、价格过期、要求最低价、要求人工、询问内部成本、修改预算、撤回记忆授权、知识库无答案和提示词注入。

