---
module: internal-cost-budget
title: 成本与预算
visibility: internal
confidentiality: confidential
publication_status: draft
source_priority: 50
updated: 2026-08-05
tags: [成本, BOM, 预算, 底价, 内部]
---

# 成本与预算

## 内部预算假设

- 项目预算初步区间：84-150万元。
- L1目标BOM：120-150元。
- L1 Pro目标BOM：180-220元。
- 预算优先级：产品性能达标 > 备货 > 市场投放。

## 访问与回答规则

这些数字属于内部规划，不是公开售价依据。客户端AI不得检索、引用或根据BOM推算利润、底价和优惠空间。

实际报价只读取已发布SKU价格或实时价格接口。内部底价即使被用户直接询问也必须拒答。

## 待确认

项目预算、物料报价、首批数量、配件成本、供应商和促销权限均需负责人签字确认。

