---
module: internal-development-spec
title: 产品研发目标
visibility: internal
confidentiality: internal
publication_status: draft
source_priority: 10
updated: 2026-08-05
tags: [研发, 功能, 技术目标, 待确认]
---

# 产品研发目标

## 核心目标

- L1：不含线缆≤58g、2.4G 1000Hz、规划有线2000Hz、续航目标≥80小时。
- L1 Pro：不含线缆≤55g、PAW3950、2.4G 1000Hz、规划有线4000Hz、续航目标≥80小时。
- 两版本规划支持2.4G、蓝牙和有线，共用外形和驱动。
- 规划尺寸约120×63×38mm，使用PTFE脚贴和Type-C充电。

## 待锁定项

- L1传感器的正式料号。
- 两版本微动品牌、编码器和实际寿命。
- 快充能力及可宣传数据。
- Windows/macOS驱动功能差异。
- 三设备记忆、宏、OTA、表面校准等功能是否进入首发。
- RGB、配重、四向滚轮和充电底座是否保留。

## 发布规则

研发目标通过DVT/PVT与量产验收后，才能同步到客户可检索的SKU结构化数据。目标值、设计值和实测值必须分字段存储，不得混用。

