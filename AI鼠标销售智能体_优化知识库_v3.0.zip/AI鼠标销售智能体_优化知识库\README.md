---
kb_name: AI鼠标销售智能体知识库
module: knowledge-base-index
project: L1系列轻量化无线鼠标
version: 3.0
updated: 2026-08-05
owner: 产品与运营
status: draft_pending_review
visibility: system
publication_status: published
---

# AI鼠标销售智能体知识库

## 用途

本知识库用于网页端AI鼠标导购，支持文字问答、意图识别、需求采集、商品推荐、商品比较、公开报价、购买链接、历史会话与授权记忆。

## 本期范围

实现：文字多轮问答、商品参数检索、三档推荐、比较、公开报价、购买入口、历史会话、客户数据和上下文管理。

不实现：本地PDF/Word/图片自动解析与向量化、自动转人工、人工排队与接管、语音回复与克隆音色。

## 目录与访问范围

### 客户事实库

| 文件 | 用途 |
|---|---|
| 01-product-catalog.md | SKU、参数、价格和购买状态 |
| 04-product-comparison.md | L1与L1 Pro统一维度比较 |
| 06-product-faq.md | 面向用户的标准问答 |
| 07-accessories-and-package.md | 标配与选配配件 |
| 08-warranty-and-support.md | 质保、售后与人工请求的边界提示 |

### 系统规则库

| 文件 | 用途 |
|---|---|
| 00-scope-and-answer-policy.md | 回答边界、事实优先级与禁止事项 |
| 02-user-needs-and-discovery.md | 用户需求采集与追问顺序 |
| 03-recommendation-rules.md | 硬过滤、排序和三档推荐规则 |
| 05-pricing-and-quote-rules.md | 报价、活动价、议价和拒答规则 |
| 09-session-memory-and-customer-data.md | 历史、记忆、授权与删除规则 |
| 10-exception-and-refusal.md | 无结果、冲突、越权和异常降级 |

### 仅内部检索

`internal/` 内为市场、研发、成本、风险、排期和硬件验收资料。客户端AI不得检索或引用。

## 检索规则

1. 面向用户的事实检索仅使用 `visibility: customer` 且 `publication_status: published` 的内容。
2. `visibility: system` 文件由编排层固定加载，用于路由和约束，不作为商品事实来源直接引用。
3. SKU、价格、兼容性优先使用结构化字段，FAQ只用于解释。
4. 同一事实冲突时，按 `source_priority` 数字由小到大选择；仍无法判断则拒答。
5. 每个二级标题作为一个语义块；表格保持整表，不拆散行列关系。
6. 回答时返回 `source_id` 和 `updated`，供前端展示“依据”。
7. `draft`、`pending`、`internal`、`confidential` 内容不得形成面向用户的确定承诺。

## 上线前必须确认

- L1与L1 Pro的最终型号、传感器、重量、续航、回报率、兼容平台和质保。
- 正式零售价、活动价、生效时间、库存状态与购买链接。
- 标配与选配清单。
- 客户数据保存周期、账号权限和删除流程。

## 百炼导入提醒

不要一次性上传整个目录。请先阅读 `IMPORT-GUIDE.md`，将客户事实、系统规则和内部资料分开处理，避免内部信息被RAG召回。
