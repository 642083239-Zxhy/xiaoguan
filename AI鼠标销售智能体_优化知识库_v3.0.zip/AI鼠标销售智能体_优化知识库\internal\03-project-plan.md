---
module: internal-project-plan
title: 产品研发计划
visibility: internal
confidentiality: confidential
publication_status: draft
source_priority: 30
updated: 2026-08-05
tags: [排期, EVT, DVT, PVT, 量产]
---

# 产品研发计划

## 当前规划

成熟公模方案预计需要约20周：立项2周、公模与方案锁定4周、EVT/DVT 8周、PVT与量产准备4周、量产上市2周。

## 主要里程碑

1. 需求与团队确认。
2. 公模、双版本BOM与外观方案锁定。
3. EVT完成性能和手感初测。
4. DVT完成目标参数、可靠性和第三方检测。
5. PVT验证量产工艺、包装与配件。
6. 发布正式SKU、价格、售后政策和购买链接。

## 与AI知识库的同步门槛

- DVT前：只能保存内部目标，不进入客户端检索。
- DVT通过后：可录入待发布SKU草稿。
- PVT和商业评审通过后：运营将字段改为 `published`。
- 任何参数、价格或配件变化都必须更新版本号和生效时间。

