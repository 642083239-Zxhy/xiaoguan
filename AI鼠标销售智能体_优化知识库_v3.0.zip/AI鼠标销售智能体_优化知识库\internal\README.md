---
module: internal-index
title: 内部资料索引
visibility: internal
confidentiality: confidential
publication_status: published
updated: 2026-08-05
---

# 内部资料索引

本目录保存产品规划、成本、风险、研发验收等内部信息，只供产品、研发和运营人员使用。

## 安全规则

- 客户端AI检索必须过滤 `visibility: internal` 和 `confidentiality: confidential`。
- 不得向用户引用内部成本、底价、利润、供应商、未发布参数、风险或排期。
- 内部资料与已发布SKU冲突时，以已发布SKU为准，并创建数据修复任务。

## 文件

- 01-market-and-positioning.md：市场、用户和产品定位假设。
- 02-product-development-spec.md：硬件功能目标与待确认项。
- 03-project-plan.md：内部研发节奏。
- 04-cost-budget.md：内部预算与BOM目标。
- 05-risk-and-hardware-acceptance.md：硬件风险与验证要求。
- 06-ai-system-acceptance.md：AI销售智能体的功能、数据、安全与性能验收。

